HARSHAVARDHINI M — PORTFOLIO WEBSITE

FILES
- index.html: the portfolio website
- assets/Harshavardhini_M_Resume.pdf: resume linked to the Download Resume button
- assets/arduino-temperature-project.jpg: your Arduino project photo

HOW TO OPEN
1. Extract the ZIP file.
2. Open the Harshavardhini_Portfolio folder.
3. Double-click index.html. It opens in your browser.
4. Keep the assets folder next to index.html. Do not move index.html out of the folder.

HOW TO PUBLISH
You can upload the folder to a static website hosting service later. Keep the folder structure unchanged.

BEFORE SHARING
- Check your school dates and any academic details.
- Add your actual LinkedIn and GitHub profile URLs if you want them shown.
- Confirm the Arduino fan's actual behaviour before describing it as automatic.
